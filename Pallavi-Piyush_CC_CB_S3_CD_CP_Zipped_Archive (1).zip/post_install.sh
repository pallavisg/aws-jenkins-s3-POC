#!/usr/bin/env bash
sudo su
cd /home/ubuntu/temp
npm install
