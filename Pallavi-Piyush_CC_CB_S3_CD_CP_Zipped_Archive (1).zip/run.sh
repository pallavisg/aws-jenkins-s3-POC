#!/usr/bin/env bash

cd /home/ubuntu/temp
node app.js &

