
#!/usr/bin/env bash
sudo su
cd /home/ubuntu/temp
rm -rf ./*
